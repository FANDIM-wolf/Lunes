#include <iostream>
#include <fstream>
#include <iostream>
#include <sys/stat.h>
#include "string.h"
#include "keys.cpp"
#include "hash_system.h"

using namespace  std;


class Coin {
    public:
        string FILE_NAME;
        int ID ;
        int value_of_coin;



};