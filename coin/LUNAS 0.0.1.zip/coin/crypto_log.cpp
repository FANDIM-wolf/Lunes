#include <iostream>
#include <fstream>
#include <iostream>
#include <sys/stat.h>
#include "string.h"
using namespace  std;

// crypto_log
void crypto_log(){
	int coins;
}